/*
 * Copyright (C) 2018 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package androidx.media3.exoplayer.source;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.media3.common.Timeline;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.TransferListener;
import androidx.media3.exoplayer.analytics.PlayerId;
import androidx.media3.exoplayer.drm.DrmSessionEventListener;
import java.util.ArrayList;
import java.util.HashSet;

/**
 * Base {@link MediaSource} implementation to handle parallel reuse and to keep a list of {@link
 * MediaSourceEventListener}s.
 *
 * <p>Whenever an implementing subclass needs to provide a new timeline, it must call {@link
 * #refreshSourceInfo(Timeline)} to notify all listeners.
 */
@UnstableApi
public abstract class BaseMediaSource implements MediaSource {

  private final ArrayList<MediaSourceCaller> mediaSourceCallers;
  private final HashSet<MediaSourceCaller> enabledMediaSourceCallers;
  private final MediaSourceEventListener.EventDispatcher eventDispatcher;
  private final DrmSessionEventListener.EventDispatcher drmEventDispatcher;

  @Nullable private Looper looper;
  @Nullable private Timeline timeline;
  @Nullable private PlayerId playerId;

  public BaseMediaSource() {
    mediaSourceCallers = new ArrayList<>(/* initialCapacity= */ 1);
    enabledMediaSourceCallers = new HashSet<>(/* initialCapacity= */ 1);
    eventDispatcher = new MediaSourceEventListener.EventDispatcher();
    drmEventDispatcher = new DrmSessionEventListener.EventDispatcher();
  }

  /**
   * Starts source preparation and enables the source, see {@link #prepareSource(MediaSourceCaller,
   * TransferListener, PlayerId)}. This method is called at most once until the next call to {@link
   * #releaseSourceInternal()}.
   *
   * <p>This method is called on the playback thread.
   *
   * @param mediaTransferListener The transfer listener which should be informed of any media data
   *     transfers. May be null if no listener is available. Note that this listener should usually
   *     be only informed of transfers related to the media loads and not of auxiliary loads for
   *     manifests and other data.
   */
  protected abstract void prepareSourceInternal(@Nullable TransferListener mediaTransferListener);

  /** Enables the source, see {@link MediaSource#enable(MediaSourceCaller)}. */
  protected void enableInternal() {}

  /** Disables the source, see {@link MediaSource#disable(MediaSourceCaller)}. */
  protected void disableInternal() {}

  /**
   * Releases the source, see {@link MediaSource#releaseSource(MediaSourceCaller)}. This method is
   * called exactly once after each call to {@link #prepareSourceInternal(TransferListener)}.
   *
   * <p>This method is called on the playback thread.
   */
  protected abstract void releaseSourceInternal();

  /**
   * Updates timeline and manifest and notifies all listeners of the update.
   *
   * @param timeline The new {@link Timeline}.
   */
  protected final void refreshSourceInfo(Timeline timeline) {
    this.timeline = timeline;
    for (MediaSourceCaller caller : mediaSourceCallers) {
      caller.onSourceInfoRefreshed(/* source= */ this, timeline);
    }
  }

  /**
   * Returns a {@link MediaSourceEventListener.EventDispatcher} which dispatches all events to the
   * registered listeners with the specified {@link MediaPeriodId}.
   *
   * @param mediaPeriodId The {@link MediaPeriodId} to be reported with the events. May be null, if
   *     the events do not belong to a specific media period.
   * @return An event dispatcher with pre-configured media period id.
   */
  protected final MediaSourceEventListener.EventDispatcher createEventDispatcher(
      @Nullable MediaPeriodId mediaPeriodId) {
    return eventDispatcher.withParameters(/* windowIndex= */ 0, mediaPeriodId);
  }

  /**
   * Returns a {@link MediaSourceEventListener.EventDispatcher} which dispatches all events to the
   * registered listeners with the specified window index and {@link MediaPeriodId}.
   *
   * @param windowIndex The timeline window index to be reported with the events.
   * @param mediaPeriodId The {@link MediaPeriodId} to be reported with the events. May be null, if
   *     the events do not belong to a specific media period.
   * @return An event dispatcher with pre-configured media period id.
   */
  protected final MediaSourceEventListener.EventDispatcher createEventDispatcher(
      int windowIndex, @Nullable MediaPeriodId mediaPeriodId) {
    return eventDispatcher.withParameters(windowIndex, mediaPeriodId);
  }

  /**
   * Note: The {@code mediaTimeOffsetMs} passed to this method is ignored and not added to media
   * times in any way.
   *
   * @deprecated Use {@link #createEventDispatcher(MediaPeriodId)} instead.
   */
  @Deprecated
  protected final MediaSourceEventListener.EventDispatcher createEventDispatcher(
      MediaPeriodId mediaPeriodId, long mediaTimeOffsetMs) {
    checkNotNull(mediaPeriodId);
    return eventDispatcher.withParameters(/* windowIndex= */ 0, mediaPeriodId);
  }

  /**
   * Note: The {@code mediaTimeOffsetMs} passed to this method is ignored and not added to media
   * times in any way.
   *
   * @deprecated Use {@link #createEventDispatcher(int, MediaPeriodId)} instead.
   */
  @Deprecated
  protected final MediaSourceEventListener.EventDispatcher createEventDispatcher(
      int windowIndex, @Nullable MediaPeriodId mediaPeriodId, long mediaTimeOffsetMs) {
    return eventDispatcher.withParameters(windowIndex, mediaPeriodId);
  }

  /**
   * Returns a {@link DrmSessionEventListener.EventDispatcher} which dispatches all events to the
   * registered listeners with the specified {@link MediaPeriodId}
   *
   * @param mediaPeriodId The {@link MediaPeriodId} to be reported with the events. May be null, if
   *     the events do not belong to a specific media period.
   * @return An event dispatcher with pre-configured media period id.
   */
  protected final DrmSessionEventListener.EventDispatcher createDrmEventDispatcher(
      @Nullable MediaPeriodId mediaPeriodId) {
    return drmEventDispatcher.withParameters(/* windowIndex= */ 0, mediaPeriodId);
  }

  /**
   * Returns a {@link DrmSessionEventListener.EventDispatcher} which dispatches all events to the
   * registered listeners with the specified window index and {@link MediaPeriodId}.
   *
   * @param windowIndex The timeline window index to be reported with the events.
   * @param mediaPeriodId The {@link MediaPeriodId} to be reported with the events. May be null, if
   *     the events do not belong to a specific media period.
   * @return An event dispatcher with pre-configured media period id and time offset.
   */
  protected final DrmSessionEventListener.EventDispatcher createDrmEventDispatcher(
      int windowIndex, @Nullable MediaPeriodId mediaPeriodId) {
    return drmEventDispatcher.withParameters(windowIndex, mediaPeriodId);
  }

  /** Returns whether the source is enabled. */
  protected final boolean isEnabled() {
    return !enabledMediaSourceCallers.isEmpty();
  }

  /**
   * Returns the {@link PlayerId} of the player using this media source.
   *
   * <p>Must only be used when the media source is {@link #prepareSourceInternal(TransferListener)
   * prepared} or has {@linkplain #setPlayerId a player ID set}.
   */
  protected final PlayerId getPlayerId() {
    return checkNotNull(playerId);
  }

  /**
   * Sets the {@link PlayerId} of the player using this media source.
   *
   * @param playerId The player ID to be set.
   */
  protected final void setPlayerId(PlayerId playerId) {
    this.playerId = playerId;
  }

  /**
   * Returns whether the source has {@link MediaSource#prepareSource(MediaSourceCaller,
   * TransferListener, PlayerId)} called.
   */
  protected final boolean prepareSourceCalled() {
    return !mediaSourceCallers.isEmpty();
  }

  @UnstableApi
  @Override
  public final void addEventListener(Handler handler, MediaSourceEventListener eventListener) {
    checkNotNull(handler);
    checkNotNull(eventListener);
    eventDispatcher.addEventListener(handler, eventListener);
  }

  @UnstableApi
  @Override
  public final void removeEventListener(MediaSourceEventListener eventListener) {
    eventDispatcher.removeEventListener(eventListener);
  }

  @UnstableApi
  @Override
  public final void addDrmEventListener(Handler handler, DrmSessionEventListener eventListener) {
    checkNotNull(handler);
    checkNotNull(eventListener);
    drmEventDispatcher.addEventListener(handler, eventListener);
  }

  @UnstableApi
  @Override
  public final void removeDrmEventListener(DrmSessionEventListener eventListener) {
    drmEventDispatcher.removeEventListener(eventListener);
  }

  @UnstableApi
  @SuppressWarnings("deprecation") // Overriding deprecated method to make it final.
  @Override
  public final void prepareSource(
      MediaSourceCaller caller, @Nullable TransferListener mediaTransferListener) {
    prepareSource(caller, mediaTransferListener, PlayerId.UNSET);
  }

  @UnstableApi
  @Override
  public final void prepareSource(
      MediaSourceCaller caller,
      @Nullable TransferListener mediaTransferListener,
      PlayerId playerId) {
    Looper looper = Looper.myLooper();
    checkArgument(this.looper == null || this.looper == looper);
    this.playerId = playerId;
    @Nullable Timeline timeline = this.timeline;
    mediaSourceCallers.add(caller);
    if (this.looper == null) {
      this.looper = looper;
      enabledMediaSourceCallers.add(caller);
      prepareSourceInternal(mediaTransferListener);
    } else if (timeline != null) {
      enable(caller);
      caller.onSourceInfoRefreshed(/* source= */ this, timeline);
    }
  }

  @UnstableApi
  @Override
  public final void enable(MediaSourceCaller caller) {
    checkNotNull(looper);
    boolean wasDisabled = enabledMediaSourceCallers.isEmpty();
    enabledMediaSourceCallers.add(caller);
    if (wasDisabled) {
      enableInternal();
    }
  }

  @UnstableApi
  @Override
  public final void disable(MediaSourceCaller caller) {
    boolean wasEnabled = !enabledMediaSourceCallers.isEmpty();
    enabledMediaSourceCallers.remove(caller);
    if (wasEnabled && enabledMediaSourceCallers.isEmpty()) {
      disableInternal();
    }
  }

  @UnstableApi
  @Override
  public final void releaseSource(MediaSourceCaller caller) {
    mediaSourceCallers.remove(caller);
    if (mediaSourceCallers.isEmpty()) {
      looper = null;
      timeline = null;
      playerId = null;
      enabledMediaSourceCallers.clear();
      releaseSourceInternal();
    } else {
      disable(caller);
    }
  }
}

/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: bazel-out/k8-opt-exec-2B5CBBC6/bin/external/androidsdk/aidl_binary.runfiles/androidsdk/build-tools/35.0.0/aidl -b -Irunner/android_junit_runner/java -Iservices/events/java -pexternal/androidsdk/platforms/android-35/framework.aidl runner/android_junit_runner/java/androidx/test/orchestrator/callback/OrchestratorCallback.aidl bazel-out/k8-fastbuild/bin/runner/android_junit_runner/java/androidx/test/runner_aidl/runner/android_junit_runner/java/androidx/test/orchestrator/callback/OrchestratorCallback.java
 */
package androidx.test.orchestrator.callback;
/**
 * Defines an interface for remote {@link Instrumentation} service to speak to the
 * {@link AndroidTestOrchestrator]
 */
public interface OrchestratorCallback extends android.os.IInterface
{
  /** Default implementation for OrchestratorCallback. */
  public static class Default implements androidx.test.orchestrator.callback.OrchestratorCallback
  {
    /**
     * Remote instrumentations, when given the parameter listTestsForOrchestrator, must add each test
     * they wish executed to AndroidTestOrchestrator before terminating.
     */
    @Override public void addTest(java.lang.String test) throws android.os.RemoteException
    {
    }
    /**
     * Remote instrumentations should pass a notification along to AndroidTestOrchestrator whenever they get a
     * notification of test progress.  Use {@link OrchestratorService} constants to determine the notification
     * type.
     */
    @Override public void sendTestNotification(android.os.Bundle bundle) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.test.orchestrator.callback.OrchestratorCallback
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.test.orchestrator.callback.OrchestratorCallback interface,
     * generating a proxy if needed.
     */
    public static androidx.test.orchestrator.callback.OrchestratorCallback asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.test.orchestrator.callback.OrchestratorCallback))) {
        return ((androidx.test.orchestrator.callback.OrchestratorCallback)iin);
      }
      return new androidx.test.orchestrator.callback.OrchestratorCallback.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_addTest:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.addTest(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_sendTestNotification:
        {
          android.os.Bundle _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          this.sendTestNotification(_arg0);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.test.orchestrator.callback.OrchestratorCallback
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Remote instrumentations, when given the parameter listTestsForOrchestrator, must add each test
       * they wish executed to AndroidTestOrchestrator before terminating.
       */
      @Override public void addTest(java.lang.String test) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(test);
          boolean _status = mRemote.transact(Stub.TRANSACTION_addTest, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      /**
       * Remote instrumentations should pass a notification along to AndroidTestOrchestrator whenever they get a
       * notification of test progress.  Use {@link OrchestratorService} constants to determine the notification
       * type.
       */
      @Override public void sendTestNotification(android.os.Bundle bundle) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, bundle, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_sendTestNotification, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_addTest = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_sendTestNotification = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx.test.orchestrator.callback.OrchestratorCallback";
  /**
   * Remote instrumentations, when given the parameter listTestsForOrchestrator, must add each test
   * they wish executed to AndroidTestOrchestrator before terminating.
   */
  public void addTest(java.lang.String test) throws android.os.RemoteException;
  /**
   * Remote instrumentations should pass a notification along to AndroidTestOrchestrator whenever they get a
   * notification of test progress.  Use {@link OrchestratorService} constants to determine the notification
   * type.
   */
  public void sendTestNotification(android.os.Bundle bundle) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}

/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: bazel-out/k8-opt-exec-2B5CBBC6/bin/external/androidsdk/aidl_binary.runfiles/androidsdk/build-tools/35.0.0/aidl -b -Iservices/events/java -pexternal/androidsdk/platforms/android-35/framework.aidl services/events/java/androidx/test/services/events/discovery/ITestDiscoveryEvent.aidl bazel-out/k8-fastbuild/bin/services/events/java/androidx/test/services/events/events_aidl/services/events/java/androidx/test/services/events/discovery/ITestDiscoveryEvent.java
 */
package androidx.test.services.events.discovery;
/**
 * Defines an interface for {@link Instrumentation} (e.g. {@code AndroidJUnitRunner} to
 * communicate with the remote Orchestrator test discovery service.
 */
public interface ITestDiscoveryEvent extends android.os.IInterface
{
  /** Default implementation for ITestDiscoveryEvent. */
  public static class Default implements androidx.test.services.events.discovery.ITestDiscoveryEvent
  {
    /** Sends back notifications for the status of test discovery. */
    @Override public void send(androidx.test.services.events.discovery.TestDiscoveryEvent testDiscoveryEvent) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.test.services.events.discovery.ITestDiscoveryEvent
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.test.services.events.discovery.ITestDiscoveryEvent interface,
     * generating a proxy if needed.
     */
    public static androidx.test.services.events.discovery.ITestDiscoveryEvent asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.test.services.events.discovery.ITestDiscoveryEvent))) {
        return ((androidx.test.services.events.discovery.ITestDiscoveryEvent)iin);
      }
      return new androidx.test.services.events.discovery.ITestDiscoveryEvent.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_send:
        {
          androidx.test.services.events.discovery.TestDiscoveryEvent _arg0;
          _arg0 = _Parcel.readTypedObject(data, androidx.test.services.events.discovery.TestDiscoveryEvent.CREATOR);
          this.send(_arg0);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.test.services.events.discovery.ITestDiscoveryEvent
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /** Sends back notifications for the status of test discovery. */
      @Override public void send(androidx.test.services.events.discovery.TestDiscoveryEvent testDiscoveryEvent) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, testDiscoveryEvent, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_send, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_send = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx.test.services.events.discovery.ITestDiscoveryEvent";
  /** Sends back notifications for the status of test discovery. */
  public void send(androidx.test.services.events.discovery.TestDiscoveryEvent testDiscoveryEvent) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}

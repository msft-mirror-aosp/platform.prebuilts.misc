/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: bazel-out/k8-opt-exec-2B5CBBC6/bin/external/androidsdk/aidl_binary.runfiles/androidsdk/build-tools/35.0.0/aidl -b -Iespresso/core/java/androidx/test/espresso/remote/idls -pexternal/androidsdk/platforms/android-35/framework.aidl espresso/core/java/androidx/test/espresso/remote/idls/androidx/test/espresso/remote/IInteractionExecutionStatus.aidl bazel-out/k8-fastbuild/bin/espresso/core/java/androidx/test/espresso/remote/aidls_aidl/espresso/core/java/androidx/test/espresso/remote/idls/androidx/test/espresso/remote/IInteractionExecutionStatus.java
 */
package androidx.test.espresso.remote;
/**
 * Enables the ability to share interaction execution status cross process
 * @hide
 */
@androidx.annotation.RestrictTo(androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP)
public interface IInteractionExecutionStatus extends android.os.IInterface
{
  /** Default implementation for IInteractionExecutionStatus. */
  public static class Default implements androidx.test.espresso.remote.IInteractionExecutionStatus
  {
    /**
     * Returns {@code false} if the given interaction was already executed on the
     * remote process
     */
    @Override public boolean canExecute() throws android.os.RemoteException
    {
      return false;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.test.espresso.remote.IInteractionExecutionStatus
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.test.espresso.remote.IInteractionExecutionStatus interface,
     * generating a proxy if needed.
     */
    public static androidx.test.espresso.remote.IInteractionExecutionStatus asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.test.espresso.remote.IInteractionExecutionStatus))) {
        return ((androidx.test.espresso.remote.IInteractionExecutionStatus)iin);
      }
      return new androidx.test.espresso.remote.IInteractionExecutionStatus.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_canExecute:
        {
          boolean _result = this.canExecute();
          reply.writeNoException();
          reply.writeInt(((_result)?(1):(0)));
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.test.espresso.remote.IInteractionExecutionStatus
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      /**
       * Returns {@code false} if the given interaction was already executed on the
       * remote process
       */
      @Override public boolean canExecute() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        boolean _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_canExecute, _data, _reply, 0);
          _reply.readException();
          _result = (0!=_reply.readInt());
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_canExecute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx.test.espresso.remote.IInteractionExecutionStatus";
  /**
   * Returns {@code false} if the given interaction was already executed on the
   * remote process
   */
  public boolean canExecute() throws android.os.RemoteException;
}

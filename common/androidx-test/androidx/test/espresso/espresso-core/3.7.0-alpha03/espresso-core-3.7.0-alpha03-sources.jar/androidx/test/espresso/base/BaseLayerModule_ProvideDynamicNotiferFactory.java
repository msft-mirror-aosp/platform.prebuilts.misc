package androidx.test.espresso.base;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideDynamicNotiferFactory implements Factory<IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback>> {
  private final BaseLayerModule module;

  private final Provider<IdlingResourceRegistry> dynamicRegistryProvider;

  public BaseLayerModule_ProvideDynamicNotiferFactory(BaseLayerModule module,
      Provider<IdlingResourceRegistry> dynamicRegistryProvider) {
    this.module = module;
    this.dynamicRegistryProvider = dynamicRegistryProvider;
  }

  @Override
  public IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback> get() {
    return provideDynamicNotifer(module, dynamicRegistryProvider.get());
  }

  public static BaseLayerModule_ProvideDynamicNotiferFactory create(BaseLayerModule module,
      Provider<IdlingResourceRegistry> dynamicRegistryProvider) {
    return new BaseLayerModule_ProvideDynamicNotiferFactory(module, dynamicRegistryProvider);
  }

  public static IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback> provideDynamicNotifer(
      BaseLayerModule instance, IdlingResourceRegistry dynamicRegistry) {
    return Preconditions.checkNotNullFromProvides(instance.provideDynamicNotifer(dynamicRegistry));
  }
}

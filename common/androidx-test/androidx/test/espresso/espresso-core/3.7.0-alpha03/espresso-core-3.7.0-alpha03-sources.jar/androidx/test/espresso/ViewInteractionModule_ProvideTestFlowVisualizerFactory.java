package androidx.test.espresso;

import androidx.test.espresso.internal.data.TestFlowVisualizer;
import androidx.test.platform.io.PlatformTestStorage;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideTestFlowVisualizerFactory implements Factory<TestFlowVisualizer> {
  private final ViewInteractionModule module;

  private final Provider<PlatformTestStorage> platformTestStorageProvider;

  public ViewInteractionModule_ProvideTestFlowVisualizerFactory(ViewInteractionModule module,
      Provider<PlatformTestStorage> platformTestStorageProvider) {
    this.module = module;
    this.platformTestStorageProvider = platformTestStorageProvider;
  }

  @Override
  public TestFlowVisualizer get() {
    return provideTestFlowVisualizer(module, platformTestStorageProvider.get());
  }

  public static ViewInteractionModule_ProvideTestFlowVisualizerFactory create(
      ViewInteractionModule module, Provider<PlatformTestStorage> platformTestStorageProvider) {
    return new ViewInteractionModule_ProvideTestFlowVisualizerFactory(module, platformTestStorageProvider);
  }

  public static TestFlowVisualizer provideTestFlowVisualizer(ViewInteractionModule instance,
      PlatformTestStorage platformTestStorage) {
    return Preconditions.checkNotNullFromProvides(instance.provideTestFlowVisualizer(platformTestStorage));
  }
}

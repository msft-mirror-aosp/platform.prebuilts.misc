package androidx.test.espresso.base;

import android.os.Looper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata({
    "androidx.test.espresso.base.SdkAsyncTask",
    "androidx.test.espresso.base.CompatAsyncTask"
})
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class UiControllerImpl_Factory implements Factory<UiControllerImpl> {
  private final Provider<EventInjector> eventInjectorProvider;

  private final Provider<IdleNotifier<Runnable>> asyncIdleProvider;

  private final Provider<IdleNotifier<Runnable>> compatIdleProvider;

  private final Provider<IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback>> dynamicIdleProvider;

  private final Provider<Looper> mainLooperProvider;

  private final Provider<IdlingResourceRegistry> idlingResourceRegistryProvider;

  public UiControllerImpl_Factory(Provider<EventInjector> eventInjectorProvider,
      Provider<IdleNotifier<Runnable>> asyncIdleProvider,
      Provider<IdleNotifier<Runnable>> compatIdleProvider,
      Provider<IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback>> dynamicIdleProvider,
      Provider<Looper> mainLooperProvider,
      Provider<IdlingResourceRegistry> idlingResourceRegistryProvider) {
    this.eventInjectorProvider = eventInjectorProvider;
    this.asyncIdleProvider = asyncIdleProvider;
    this.compatIdleProvider = compatIdleProvider;
    this.dynamicIdleProvider = dynamicIdleProvider;
    this.mainLooperProvider = mainLooperProvider;
    this.idlingResourceRegistryProvider = idlingResourceRegistryProvider;
  }

  @Override
  public UiControllerImpl get() {
    return newInstance(eventInjectorProvider.get(), asyncIdleProvider.get(), compatIdleProvider.get(), dynamicIdleProvider, mainLooperProvider.get(), idlingResourceRegistryProvider.get());
  }

  public static UiControllerImpl_Factory create(Provider<EventInjector> eventInjectorProvider,
      Provider<IdleNotifier<Runnable>> asyncIdleProvider,
      Provider<IdleNotifier<Runnable>> compatIdleProvider,
      Provider<IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback>> dynamicIdleProvider,
      Provider<Looper> mainLooperProvider,
      Provider<IdlingResourceRegistry> idlingResourceRegistryProvider) {
    return new UiControllerImpl_Factory(eventInjectorProvider, asyncIdleProvider, compatIdleProvider, dynamicIdleProvider, mainLooperProvider, idlingResourceRegistryProvider);
  }

  public static UiControllerImpl newInstance(Object eventInjector, Object asyncIdle,
      Object compatIdle,
      Provider<IdleNotifier<IdlingResourceRegistry.IdleNotificationCallback>> dynamicIdle,
      Looper mainLooper, IdlingResourceRegistry idlingResourceRegistry) {
    return new UiControllerImpl((EventInjector) eventInjector, (IdleNotifier<Runnable>) asyncIdle, (IdleNotifier<Runnable>) compatIdle, dynamicIdle, mainLooper, idlingResourceRegistry);
  }
}

package androidx.test.espresso;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.processing.Generated;
import org.hamcrest.Matcher;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideRootMatcherFactory implements Factory<AtomicReference<Matcher<Root>>> {
  private final ViewInteractionModule module;

  public ViewInteractionModule_ProvideRootMatcherFactory(ViewInteractionModule module) {
    this.module = module;
  }

  @Override
  public AtomicReference<Matcher<Root>> get() {
    return provideRootMatcher(module);
  }

  public static ViewInteractionModule_ProvideRootMatcherFactory create(
      ViewInteractionModule module) {
    return new ViewInteractionModule_ProvideRootMatcherFactory(module);
  }

  public static AtomicReference<Matcher<Root>> provideRootMatcher(ViewInteractionModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideRootMatcher());
  }
}

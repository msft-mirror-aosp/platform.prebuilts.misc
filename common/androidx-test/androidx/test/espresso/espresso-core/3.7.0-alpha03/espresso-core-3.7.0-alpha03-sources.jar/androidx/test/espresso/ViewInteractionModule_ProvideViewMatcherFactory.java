package androidx.test.espresso;

import android.view.View;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import org.hamcrest.Matcher;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideViewMatcherFactory implements Factory<Matcher<View>> {
  private final ViewInteractionModule module;

  public ViewInteractionModule_ProvideViewMatcherFactory(ViewInteractionModule module) {
    this.module = module;
  }

  @Override
  public Matcher<View> get() {
    return provideViewMatcher(module);
  }

  public static ViewInteractionModule_ProvideViewMatcherFactory create(
      ViewInteractionModule module) {
    return new ViewInteractionModule_ProvideViewMatcherFactory(module);
  }

  public static Matcher<View> provideViewMatcher(ViewInteractionModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideViewMatcher());
  }
}

package androidx.test.espresso.base;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideActiveRootListerFactory implements Factory<ActiveRootLister> {
  private final BaseLayerModule module;

  private final Provider<RootsOracle> rootsOracleProvider;

  public BaseLayerModule_ProvideActiveRootListerFactory(BaseLayerModule module,
      Provider<RootsOracle> rootsOracleProvider) {
    this.module = module;
    this.rootsOracleProvider = rootsOracleProvider;
  }

  @Override
  public ActiveRootLister get() {
    return provideActiveRootLister(module, rootsOracleProvider.get());
  }

  public static BaseLayerModule_ProvideActiveRootListerFactory create(BaseLayerModule module,
      Provider<RootsOracle> rootsOracleProvider) {
    return new BaseLayerModule_ProvideActiveRootListerFactory(module, rootsOracleProvider);
  }

  public static ActiveRootLister provideActiveRootLister(BaseLayerModule instance,
      Object rootsOracle) {
    return Preconditions.checkNotNullFromProvides(instance.provideActiveRootLister((RootsOracle) rootsOracle));
  }
}

package androidx.test.espresso.base;

import android.os.Looper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RootsOracle_Factory implements Factory<RootsOracle> {
  private final Provider<Looper> mainLooperProvider;

  public RootsOracle_Factory(Provider<Looper> mainLooperProvider) {
    this.mainLooperProvider = mainLooperProvider;
  }

  @Override
  public RootsOracle get() {
    return newInstance(mainLooperProvider.get());
  }

  public static RootsOracle_Factory create(Provider<Looper> mainLooperProvider) {
    return new RootsOracle_Factory(mainLooperProvider);
  }

  public static RootsOracle newInstance(Looper mainLooper) {
    return new RootsOracle(mainLooper);
  }
}

package androidx.test.espresso;

import androidx.test.espresso.base.ViewFinderImpl;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideViewFinderFactory implements Factory<ViewFinder> {
  private final ViewInteractionModule module;

  private final Provider<ViewFinderImpl> implProvider;

  public ViewInteractionModule_ProvideViewFinderFactory(ViewInteractionModule module,
      Provider<ViewFinderImpl> implProvider) {
    this.module = module;
    this.implProvider = implProvider;
  }

  @Override
  public ViewFinder get() {
    return provideViewFinder(module, implProvider.get());
  }

  public static ViewInteractionModule_ProvideViewFinderFactory create(ViewInteractionModule module,
      Provider<ViewFinderImpl> implProvider) {
    return new ViewInteractionModule_ProvideViewFinderFactory(module, implProvider);
  }

  public static ViewFinder provideViewFinder(ViewInteractionModule instance, ViewFinderImpl impl) {
    return Preconditions.checkNotNullFromProvides(instance.provideViewFinder(impl));
  }
}

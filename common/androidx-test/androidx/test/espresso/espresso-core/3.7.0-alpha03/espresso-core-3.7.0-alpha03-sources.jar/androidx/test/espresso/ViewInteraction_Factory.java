package androidx.test.espresso;

import android.view.View;
import androidx.test.espresso.internal.data.TestFlowVisualizer;
import androidx.test.espresso.remote.RemoteInteraction;
import androidx.test.espresso.util.concurrent.ListeningExecutorService;
import androidx.test.internal.platform.os.ControlledLooper;
import androidx.test.platform.tracing.Tracing;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.processing.Generated;
import javax.inject.Provider;
import org.hamcrest.Matcher;

@ScopeMetadata
@QualifierMetadata("androidx.test.espresso.base.MainThread")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteraction_Factory implements Factory<ViewInteraction> {
  private final Provider<UiController> uiControllerProvider;

  private final Provider<ViewFinder> viewFinderProvider;

  private final Provider<Executor> mainThreadExecutorProvider;

  private final Provider<FailureHandler> failureHandlerProvider;

  private final Provider<Matcher<View>> viewMatcherProvider;

  private final Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider;

  private final Provider<AtomicReference<Boolean>> needsActivityProvider;

  private final Provider<RemoteInteraction> remoteInteractionProvider;

  private final Provider<ListeningExecutorService> remoteExecutorProvider;

  private final Provider<ControlledLooper> controlledLooperProvider;

  private final Provider<TestFlowVisualizer> testFlowVisualizerProvider;

  private final Provider<Tracing> tracerProvider;

  public ViewInteraction_Factory(Provider<UiController> uiControllerProvider,
      Provider<ViewFinder> viewFinderProvider, Provider<Executor> mainThreadExecutorProvider,
      Provider<FailureHandler> failureHandlerProvider, Provider<Matcher<View>> viewMatcherProvider,
      Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider,
      Provider<AtomicReference<Boolean>> needsActivityProvider,
      Provider<RemoteInteraction> remoteInteractionProvider,
      Provider<ListeningExecutorService> remoteExecutorProvider,
      Provider<ControlledLooper> controlledLooperProvider,
      Provider<TestFlowVisualizer> testFlowVisualizerProvider, Provider<Tracing> tracerProvider) {
    this.uiControllerProvider = uiControllerProvider;
    this.viewFinderProvider = viewFinderProvider;
    this.mainThreadExecutorProvider = mainThreadExecutorProvider;
    this.failureHandlerProvider = failureHandlerProvider;
    this.viewMatcherProvider = viewMatcherProvider;
    this.rootMatcherRefProvider = rootMatcherRefProvider;
    this.needsActivityProvider = needsActivityProvider;
    this.remoteInteractionProvider = remoteInteractionProvider;
    this.remoteExecutorProvider = remoteExecutorProvider;
    this.controlledLooperProvider = controlledLooperProvider;
    this.testFlowVisualizerProvider = testFlowVisualizerProvider;
    this.tracerProvider = tracerProvider;
  }

  @Override
  public ViewInteraction get() {
    return newInstance(uiControllerProvider.get(), viewFinderProvider.get(), mainThreadExecutorProvider.get(), failureHandlerProvider.get(), viewMatcherProvider.get(), rootMatcherRefProvider.get(), needsActivityProvider.get(), remoteInteractionProvider.get(), remoteExecutorProvider.get(), controlledLooperProvider.get(), testFlowVisualizerProvider.get(), tracerProvider.get());
  }

  public static ViewInteraction_Factory create(Provider<UiController> uiControllerProvider,
      Provider<ViewFinder> viewFinderProvider, Provider<Executor> mainThreadExecutorProvider,
      Provider<FailureHandler> failureHandlerProvider, Provider<Matcher<View>> viewMatcherProvider,
      Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider,
      Provider<AtomicReference<Boolean>> needsActivityProvider,
      Provider<RemoteInteraction> remoteInteractionProvider,
      Provider<ListeningExecutorService> remoteExecutorProvider,
      Provider<ControlledLooper> controlledLooperProvider,
      Provider<TestFlowVisualizer> testFlowVisualizerProvider, Provider<Tracing> tracerProvider) {
    return new ViewInteraction_Factory(uiControllerProvider, viewFinderProvider, mainThreadExecutorProvider, failureHandlerProvider, viewMatcherProvider, rootMatcherRefProvider, needsActivityProvider, remoteInteractionProvider, remoteExecutorProvider, controlledLooperProvider, testFlowVisualizerProvider, tracerProvider);
  }

  public static ViewInteraction newInstance(UiController uiController, ViewFinder viewFinder,
      Executor mainThreadExecutor, FailureHandler failureHandler, Matcher<View> viewMatcher,
      AtomicReference<Matcher<Root>> rootMatcherRef, AtomicReference<Boolean> needsActivity,
      RemoteInteraction remoteInteraction, ListeningExecutorService remoteExecutor,
      ControlledLooper controlledLooper, TestFlowVisualizer testFlowVisualizer, Tracing tracer) {
    return new ViewInteraction(uiController, viewFinder, mainThreadExecutor, failureHandler, viewMatcher, rootMatcherRef, needsActivity, remoteInteraction, remoteExecutor, controlledLooper, testFlowVisualizer, tracer);
  }
}

package androidx.test.espresso.base;

import androidx.test.platform.tracing.Tracing;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvidesTracingFactory implements Factory<Tracing> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvidesTracingFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public Tracing get() {
    return providesTracing(module);
  }

  public static BaseLayerModule_ProvidesTracingFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvidesTracingFactory(module);
  }

  public static Tracing providesTracing(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.providesTracing());
  }
}

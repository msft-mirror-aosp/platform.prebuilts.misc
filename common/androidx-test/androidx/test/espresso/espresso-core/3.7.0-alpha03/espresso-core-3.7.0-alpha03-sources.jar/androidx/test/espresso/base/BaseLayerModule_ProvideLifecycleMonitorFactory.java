package androidx.test.espresso.base;

import androidx.test.runner.lifecycle.ActivityLifecycleMonitor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideLifecycleMonitorFactory implements Factory<ActivityLifecycleMonitor> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideLifecycleMonitorFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public ActivityLifecycleMonitor get() {
    return provideLifecycleMonitor(module);
  }

  public static BaseLayerModule_ProvideLifecycleMonitorFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideLifecycleMonitorFactory(module);
  }

  public static ActivityLifecycleMonitor provideLifecycleMonitor(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideLifecycleMonitor());
  }
}

package androidx.test.espresso.base;

import android.content.Context;
import androidx.test.espresso.UiController;
import androidx.test.internal.platform.os.ControlledLooper;
import androidx.test.runner.lifecycle.ActivityLifecycleMonitor;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("androidx.test.espresso.base.RootViewPickerScope")
@QualifierMetadata("androidx.test.espresso.internal.inject.TargetContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RootViewPicker_Factory implements Factory<RootViewPicker> {
  private final Provider<UiController> uiControllerProvider;

  private final Provider<RootViewPicker.RootResultFetcher> rootResultFetcherProvider;

  private final Provider<ActivityLifecycleMonitor> activityLifecycleMonitorProvider;

  private final Provider<AtomicReference<Boolean>> needsActivityProvider;

  private final Provider<ControlledLooper> controlledLooperProvider;

  private final Provider<Context> appContextProvider;

  public RootViewPicker_Factory(Provider<UiController> uiControllerProvider,
      Provider<RootViewPicker.RootResultFetcher> rootResultFetcherProvider,
      Provider<ActivityLifecycleMonitor> activityLifecycleMonitorProvider,
      Provider<AtomicReference<Boolean>> needsActivityProvider,
      Provider<ControlledLooper> controlledLooperProvider, Provider<Context> appContextProvider) {
    this.uiControllerProvider = uiControllerProvider;
    this.rootResultFetcherProvider = rootResultFetcherProvider;
    this.activityLifecycleMonitorProvider = activityLifecycleMonitorProvider;
    this.needsActivityProvider = needsActivityProvider;
    this.controlledLooperProvider = controlledLooperProvider;
    this.appContextProvider = appContextProvider;
  }

  @Override
  public RootViewPicker get() {
    return newInstance(uiControllerProvider.get(), rootResultFetcherProvider.get(), activityLifecycleMonitorProvider.get(), needsActivityProvider.get(), controlledLooperProvider.get(), appContextProvider.get());
  }

  public static RootViewPicker_Factory create(Provider<UiController> uiControllerProvider,
      Provider<RootViewPicker.RootResultFetcher> rootResultFetcherProvider,
      Provider<ActivityLifecycleMonitor> activityLifecycleMonitorProvider,
      Provider<AtomicReference<Boolean>> needsActivityProvider,
      Provider<ControlledLooper> controlledLooperProvider, Provider<Context> appContextProvider) {
    return new RootViewPicker_Factory(uiControllerProvider, rootResultFetcherProvider, activityLifecycleMonitorProvider, needsActivityProvider, controlledLooperProvider, appContextProvider);
  }

  public static RootViewPicker newInstance(UiController uiController, Object rootResultFetcher,
      ActivityLifecycleMonitor activityLifecycleMonitor, AtomicReference<Boolean> needsActivity,
      ControlledLooper controlledLooper, Context appContext) {
    return new RootViewPicker(uiController, (RootViewPicker.RootResultFetcher) rootResultFetcher, activityLifecycleMonitor, needsActivity, controlledLooper, appContext);
  }
}

package androidx.test.espresso.base;

import androidx.test.internal.platform.os.ControlledLooper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideControlledLooperFactory implements Factory<ControlledLooper> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideControlledLooperFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public ControlledLooper get() {
    return provideControlledLooper(module);
  }

  public static BaseLayerModule_ProvideControlledLooperFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideControlledLooperFactory(module);
  }

  public static ControlledLooper provideControlledLooper(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideControlledLooper());
  }
}

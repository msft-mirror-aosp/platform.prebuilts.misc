package androidx.test.espresso.base;

import android.os.Looper;
import androidx.test.platform.tracing.Tracing;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class IdlingResourceRegistry_Factory implements Factory<IdlingResourceRegistry> {
  private final Provider<Looper> looperProvider;

  private final Provider<Tracing> tracerProvider;

  public IdlingResourceRegistry_Factory(Provider<Looper> looperProvider,
      Provider<Tracing> tracerProvider) {
    this.looperProvider = looperProvider;
    this.tracerProvider = tracerProvider;
  }

  @Override
  public IdlingResourceRegistry get() {
    return newInstance(looperProvider.get(), tracerProvider.get());
  }

  public static IdlingResourceRegistry_Factory create(Provider<Looper> looperProvider,
      Provider<Tracing> tracerProvider) {
    return new IdlingResourceRegistry_Factory(looperProvider, tracerProvider);
  }

  public static IdlingResourceRegistry newInstance(Looper looper, Tracing tracer) {
    return new IdlingResourceRegistry(looper, tracer);
  }
}

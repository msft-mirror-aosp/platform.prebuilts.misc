package androidx.test.espresso;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideNeedsActivityFactory implements Factory<AtomicReference<Boolean>> {
  private final ViewInteractionModule module;

  public ViewInteractionModule_ProvideNeedsActivityFactory(ViewInteractionModule module) {
    this.module = module;
  }

  @Override
  public AtomicReference<Boolean> get() {
    return provideNeedsActivity(module);
  }

  public static ViewInteractionModule_ProvideNeedsActivityFactory create(
      ViewInteractionModule module) {
    return new ViewInteractionModule_ProvideNeedsActivityFactory(module);
  }

  public static AtomicReference<Boolean> provideNeedsActivity(ViewInteractionModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideNeedsActivity());
  }
}

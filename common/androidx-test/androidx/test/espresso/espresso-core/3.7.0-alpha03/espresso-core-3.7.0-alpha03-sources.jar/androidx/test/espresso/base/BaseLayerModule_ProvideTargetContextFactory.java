package androidx.test.espresso.base;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata("androidx.test.espresso.internal.inject.TargetContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideTargetContextFactory implements Factory<Context> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideTargetContextFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public Context get() {
    return provideTargetContext(module);
  }

  public static BaseLayerModule_ProvideTargetContextFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideTargetContextFactory(module);
  }

  public static Context provideTargetContext(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideTargetContext());
  }
}

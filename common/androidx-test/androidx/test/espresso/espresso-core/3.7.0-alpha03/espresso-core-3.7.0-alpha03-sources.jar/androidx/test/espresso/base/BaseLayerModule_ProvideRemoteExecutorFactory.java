package androidx.test.espresso.base;

import androidx.test.espresso.util.concurrent.ListeningExecutorService;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideRemoteExecutorFactory implements Factory<ListeningExecutorService> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideRemoteExecutorFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public ListeningExecutorService get() {
    return provideRemoteExecutor(module);
  }

  public static BaseLayerModule_ProvideRemoteExecutorFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideRemoteExecutorFactory(module);
  }

  public static ListeningExecutorService provideRemoteExecutor(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideRemoteExecutor());
  }
}

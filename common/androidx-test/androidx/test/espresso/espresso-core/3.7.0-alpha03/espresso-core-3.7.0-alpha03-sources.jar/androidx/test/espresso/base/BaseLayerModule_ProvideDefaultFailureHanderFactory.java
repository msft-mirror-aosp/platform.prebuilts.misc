package androidx.test.espresso.base;

import android.content.Context;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata("androidx.test.espresso.internal.inject.TargetContext")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideDefaultFailureHanderFactory implements Factory<DefaultFailureHandler> {
  private final BaseLayerModule module;

  private final Provider<Context> contextProvider;

  public BaseLayerModule_ProvideDefaultFailureHanderFactory(BaseLayerModule module,
      Provider<Context> contextProvider) {
    this.module = module;
    this.contextProvider = contextProvider;
  }

  @Override
  public DefaultFailureHandler get() {
    return provideDefaultFailureHander(module, contextProvider.get());
  }

  public static BaseLayerModule_ProvideDefaultFailureHanderFactory create(BaseLayerModule module,
      Provider<Context> contextProvider) {
    return new BaseLayerModule_ProvideDefaultFailureHanderFactory(module, contextProvider);
  }

  public static DefaultFailureHandler provideDefaultFailureHander(BaseLayerModule instance,
      Context context) {
    return Preconditions.checkNotNullFromProvides(instance.provideDefaultFailureHander(context));
  }
}

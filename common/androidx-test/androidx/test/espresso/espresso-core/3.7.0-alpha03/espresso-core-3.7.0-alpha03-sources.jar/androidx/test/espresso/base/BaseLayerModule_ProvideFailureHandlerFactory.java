package androidx.test.espresso.base;

import androidx.test.espresso.FailureHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideFailureHandlerFactory implements Factory<FailureHandler> {
  private final BaseLayerModule module;

  private final Provider<BaseLayerModule.FailureHandlerHolder> holderProvider;

  public BaseLayerModule_ProvideFailureHandlerFactory(BaseLayerModule module,
      Provider<BaseLayerModule.FailureHandlerHolder> holderProvider) {
    this.module = module;
    this.holderProvider = holderProvider;
  }

  @Override
  public FailureHandler get() {
    return provideFailureHandler(module, holderProvider.get());
  }

  public static BaseLayerModule_ProvideFailureHandlerFactory create(BaseLayerModule module,
      Provider<BaseLayerModule.FailureHandlerHolder> holderProvider) {
    return new BaseLayerModule_ProvideFailureHandlerFactory(module, holderProvider);
  }

  public static FailureHandler provideFailureHandler(BaseLayerModule instance,
      BaseLayerModule.FailureHandlerHolder holder) {
    return Preconditions.checkNotNullFromProvides(instance.provideFailureHandler(holder));
  }
}

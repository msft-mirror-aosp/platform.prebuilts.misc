package androidx.test.espresso.base;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideEventInjectorFactory implements Factory<EventInjector> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideEventInjectorFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public EventInjector get() {
    return provideEventInjector(module);
  }

  public static BaseLayerModule_ProvideEventInjectorFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideEventInjectorFactory(module);
  }

  public static EventInjector provideEventInjector(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideEventInjector());
  }
}

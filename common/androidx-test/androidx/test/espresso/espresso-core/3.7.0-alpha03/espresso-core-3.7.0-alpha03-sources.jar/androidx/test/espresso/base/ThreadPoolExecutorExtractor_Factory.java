package androidx.test.espresso.base;

import android.os.Looper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ThreadPoolExecutorExtractor_Factory implements Factory<ThreadPoolExecutorExtractor> {
  private final Provider<Looper> looperProvider;

  public ThreadPoolExecutorExtractor_Factory(Provider<Looper> looperProvider) {
    this.looperProvider = looperProvider;
  }

  @Override
  public ThreadPoolExecutorExtractor get() {
    return newInstance(looperProvider.get());
  }

  public static ThreadPoolExecutorExtractor_Factory create(Provider<Looper> looperProvider) {
    return new ThreadPoolExecutorExtractor_Factory(looperProvider);
  }

  public static ThreadPoolExecutorExtractor newInstance(Looper looper) {
    return new ThreadPoolExecutorExtractor(looper);
  }
}

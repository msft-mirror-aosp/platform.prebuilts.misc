package androidx.test.espresso.base;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("androidx.test.espresso.base.SdkAsyncTask")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideSdkAsyncTaskMonitorFactory implements Factory<IdleNotifier<Runnable>> {
  private final BaseLayerModule module;

  private final Provider<ThreadPoolExecutorExtractor> extractorProvider;

  public BaseLayerModule_ProvideSdkAsyncTaskMonitorFactory(BaseLayerModule module,
      Provider<ThreadPoolExecutorExtractor> extractorProvider) {
    this.module = module;
    this.extractorProvider = extractorProvider;
  }

  @Override
  public IdleNotifier<Runnable> get() {
    return provideSdkAsyncTaskMonitor(module, extractorProvider.get());
  }

  public static BaseLayerModule_ProvideSdkAsyncTaskMonitorFactory create(BaseLayerModule module,
      Provider<ThreadPoolExecutorExtractor> extractorProvider) {
    return new BaseLayerModule_ProvideSdkAsyncTaskMonitorFactory(module, extractorProvider);
  }

  public static IdleNotifier<Runnable> provideSdkAsyncTaskMonitor(BaseLayerModule instance,
      Object extractor) {
    return Preconditions.checkNotNullFromProvides(instance.provideSdkAsyncTaskMonitor((ThreadPoolExecutorExtractor) extractor));
  }
}

package androidx.test.espresso.base;

import android.os.Looper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.Executor;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("androidx.test.espresso.base.MainThread")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideMainThreadExecutorFactory implements Factory<Executor> {
  private final BaseLayerModule module;

  private final Provider<Looper> mainLooperProvider;

  public BaseLayerModule_ProvideMainThreadExecutorFactory(BaseLayerModule module,
      Provider<Looper> mainLooperProvider) {
    this.module = module;
    this.mainLooperProvider = mainLooperProvider;
  }

  @Override
  public Executor get() {
    return provideMainThreadExecutor(module, mainLooperProvider.get());
  }

  public static BaseLayerModule_ProvideMainThreadExecutorFactory create(BaseLayerModule module,
      Provider<Looper> mainLooperProvider) {
    return new BaseLayerModule_ProvideMainThreadExecutorFactory(module, mainLooperProvider);
  }

  public static Executor provideMainThreadExecutor(BaseLayerModule instance, Looper mainLooper) {
    return Preconditions.checkNotNullFromProvides(instance.provideMainThreadExecutor(mainLooper));
  }
}

package androidx.test.espresso.base;

import android.view.View;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;
import org.hamcrest.Matcher;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewFinderImpl_Factory implements Factory<ViewFinderImpl> {
  private final Provider<Matcher<View>> viewMatcherProvider;

  private final Provider<View> rootViewProvider;

  public ViewFinderImpl_Factory(Provider<Matcher<View>> viewMatcherProvider,
      Provider<View> rootViewProvider) {
    this.viewMatcherProvider = viewMatcherProvider;
    this.rootViewProvider = rootViewProvider;
  }

  @Override
  public ViewFinderImpl get() {
    return newInstance(viewMatcherProvider.get(), rootViewProvider);
  }

  public static ViewFinderImpl_Factory create(Provider<Matcher<View>> viewMatcherProvider,
      Provider<View> rootViewProvider) {
    return new ViewFinderImpl_Factory(viewMatcherProvider, rootViewProvider);
  }

  public static ViewFinderImpl newInstance(Matcher<View> viewMatcher,
      Provider<View> rootViewProvider) {
    return new ViewFinderImpl(viewMatcher, rootViewProvider);
  }
}

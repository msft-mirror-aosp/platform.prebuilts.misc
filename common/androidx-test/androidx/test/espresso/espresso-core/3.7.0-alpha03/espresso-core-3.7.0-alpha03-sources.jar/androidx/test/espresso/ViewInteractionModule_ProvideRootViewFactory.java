package androidx.test.espresso;

import android.view.View;
import androidx.test.espresso.base.RootViewPicker;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideRootViewFactory implements Factory<View> {
  private final ViewInteractionModule module;

  private final Provider<RootViewPicker> rootViewPickerProvider;

  public ViewInteractionModule_ProvideRootViewFactory(ViewInteractionModule module,
      Provider<RootViewPicker> rootViewPickerProvider) {
    this.module = module;
    this.rootViewPickerProvider = rootViewPickerProvider;
  }

  @Override
  public View get() {
    return provideRootView(module, rootViewPickerProvider.get());
  }

  public static ViewInteractionModule_ProvideRootViewFactory create(ViewInteractionModule module,
      Provider<RootViewPicker> rootViewPickerProvider) {
    return new ViewInteractionModule_ProvideRootViewFactory(module, rootViewPickerProvider);
  }

  public static View provideRootView(ViewInteractionModule instance,
      RootViewPicker rootViewPicker) {
    return Preconditions.checkNotNullFromProvides(instance.provideRootView(rootViewPicker));
  }
}

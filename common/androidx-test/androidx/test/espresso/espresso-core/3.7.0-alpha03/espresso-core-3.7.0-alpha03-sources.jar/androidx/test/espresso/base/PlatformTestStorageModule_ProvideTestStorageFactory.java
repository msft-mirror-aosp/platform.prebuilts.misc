package androidx.test.espresso.base;

import androidx.test.platform.io.PlatformTestStorage;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class PlatformTestStorageModule_ProvideTestStorageFactory implements Factory<PlatformTestStorage> {
  private final PlatformTestStorageModule module;

  public PlatformTestStorageModule_ProvideTestStorageFactory(PlatformTestStorageModule module) {
    this.module = module;
  }

  @Override
  public PlatformTestStorage get() {
    return provideTestStorage(module);
  }

  public static PlatformTestStorageModule_ProvideTestStorageFactory create(
      PlatformTestStorageModule module) {
    return new PlatformTestStorageModule_ProvideTestStorageFactory(module);
  }

  public static PlatformTestStorage provideTestStorage(PlatformTestStorageModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideTestStorage());
  }
}

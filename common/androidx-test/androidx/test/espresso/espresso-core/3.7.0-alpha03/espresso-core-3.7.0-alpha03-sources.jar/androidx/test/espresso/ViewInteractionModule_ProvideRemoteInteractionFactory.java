package androidx.test.espresso;

import androidx.test.espresso.remote.RemoteInteraction;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class ViewInteractionModule_ProvideRemoteInteractionFactory implements Factory<RemoteInteraction> {
  private final ViewInteractionModule module;

  public ViewInteractionModule_ProvideRemoteInteractionFactory(ViewInteractionModule module) {
    this.module = module;
  }

  @Override
  public RemoteInteraction get() {
    return provideRemoteInteraction(module);
  }

  public static ViewInteractionModule_ProvideRemoteInteractionFactory create(
      ViewInteractionModule module) {
    return new ViewInteractionModule_ProvideRemoteInteractionFactory(module);
  }

  public static RemoteInteraction provideRemoteInteraction(ViewInteractionModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideRemoteInteraction());
  }
}

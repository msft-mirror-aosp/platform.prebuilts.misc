package androidx.test.espresso.base;

import androidx.test.espresso.Root;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.processing.Generated;
import javax.inject.Provider;
import org.hamcrest.Matcher;

@ScopeMetadata
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class RootViewPicker_RootResultFetcher_Factory implements Factory<RootViewPicker.RootResultFetcher> {
  private final Provider<ActiveRootLister> activeRootListerProvider;

  private final Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider;

  public RootViewPicker_RootResultFetcher_Factory(
      Provider<ActiveRootLister> activeRootListerProvider,
      Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider) {
    this.activeRootListerProvider = activeRootListerProvider;
    this.rootMatcherRefProvider = rootMatcherRefProvider;
  }

  @Override
  public RootViewPicker.RootResultFetcher get() {
    return newInstance(activeRootListerProvider.get(), rootMatcherRefProvider.get());
  }

  public static RootViewPicker_RootResultFetcher_Factory create(
      Provider<ActiveRootLister> activeRootListerProvider,
      Provider<AtomicReference<Matcher<Root>>> rootMatcherRefProvider) {
    return new RootViewPicker_RootResultFetcher_Factory(activeRootListerProvider, rootMatcherRefProvider);
  }

  public static RootViewPicker.RootResultFetcher newInstance(ActiveRootLister activeRootLister,
      AtomicReference<Matcher<Root>> rootMatcherRef) {
    return new RootViewPicker.RootResultFetcher(activeRootLister, rootMatcherRef);
  }
}

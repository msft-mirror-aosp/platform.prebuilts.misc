package androidx.test.espresso.base;

import android.os.Looper;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideMainLooperFactory implements Factory<Looper> {
  private final BaseLayerModule module;

  public BaseLayerModule_ProvideMainLooperFactory(BaseLayerModule module) {
    this.module = module;
  }

  @Override
  public Looper get() {
    return provideMainLooper(module);
  }

  public static BaseLayerModule_ProvideMainLooperFactory create(BaseLayerModule module) {
    return new BaseLayerModule_ProvideMainLooperFactory(module);
  }

  public static Looper provideMainLooper(BaseLayerModule instance) {
    return Preconditions.checkNotNullFromProvides(instance.provideMainLooper());
  }
}

package androidx.test.espresso.base;

import androidx.test.espresso.FailureHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata
@QualifierMetadata("androidx.test.espresso.base.Default")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideFailureHanderFactory implements Factory<FailureHandler> {
  private final BaseLayerModule module;

  private final Provider<DefaultFailureHandler> implProvider;

  public BaseLayerModule_ProvideFailureHanderFactory(BaseLayerModule module,
      Provider<DefaultFailureHandler> implProvider) {
    this.module = module;
    this.implProvider = implProvider;
  }

  @Override
  public FailureHandler get() {
    return provideFailureHander(module, implProvider.get());
  }

  public static BaseLayerModule_ProvideFailureHanderFactory create(BaseLayerModule module,
      Provider<DefaultFailureHandler> implProvider) {
    return new BaseLayerModule_ProvideFailureHanderFactory(module, implProvider);
  }

  public static FailureHandler provideFailureHander(BaseLayerModule instance,
      DefaultFailureHandler impl) {
    return Preconditions.checkNotNullFromProvides(instance.provideFailureHander(impl));
  }
}

package androidx.test.espresso.base;

import androidx.test.espresso.FailureHandler;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("androidx.test.espresso.base.Default")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_FailureHandlerHolder_Factory implements Factory<BaseLayerModule.FailureHandlerHolder> {
  private final Provider<FailureHandler> defaultHandlerProvider;

  public BaseLayerModule_FailureHandlerHolder_Factory(
      Provider<FailureHandler> defaultHandlerProvider) {
    this.defaultHandlerProvider = defaultHandlerProvider;
  }

  @Override
  public BaseLayerModule.FailureHandlerHolder get() {
    return newInstance(defaultHandlerProvider.get());
  }

  public static BaseLayerModule_FailureHandlerHolder_Factory create(
      Provider<FailureHandler> defaultHandlerProvider) {
    return new BaseLayerModule_FailureHandlerHolder_Factory(defaultHandlerProvider);
  }

  public static BaseLayerModule.FailureHandlerHolder newInstance(FailureHandler defaultHandler) {
    return new BaseLayerModule.FailureHandlerHolder(defaultHandler);
  }
}

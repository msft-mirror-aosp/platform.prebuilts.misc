package androidx.test.espresso.base;

import androidx.test.espresso.UiController;
import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class UiControllerModule_ProvideUiControllerFactory implements Factory<UiController> {
  private final UiControllerModule module;

  private final Provider<UiControllerImpl> uiControllerImplProvider;

  public UiControllerModule_ProvideUiControllerFactory(UiControllerModule module,
      Provider<UiControllerImpl> uiControllerImplProvider) {
    this.module = module;
    this.uiControllerImplProvider = uiControllerImplProvider;
  }

  @Override
  public UiController get() {
    return provideUiController(module, uiControllerImplProvider.get());
  }

  public static UiControllerModule_ProvideUiControllerFactory create(UiControllerModule module,
      Provider<UiControllerImpl> uiControllerImplProvider) {
    return new UiControllerModule_ProvideUiControllerFactory(module, uiControllerImplProvider);
  }

  public static UiController provideUiController(UiControllerModule instance,
      Object uiControllerImpl) {
    return Preconditions.checkNotNullFromProvides(instance.provideUiController((UiControllerImpl) uiControllerImpl));
  }
}

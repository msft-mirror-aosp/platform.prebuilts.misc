package androidx.test.espresso.base;

import dagger.internal.DaggerGenerated;
import dagger.internal.Factory;
import dagger.internal.Preconditions;
import dagger.internal.QualifierMetadata;
import dagger.internal.ScopeMetadata;
import javax.annotation.processing.Generated;
import javax.inject.Provider;

@ScopeMetadata("javax.inject.Singleton")
@QualifierMetadata("androidx.test.espresso.base.CompatAsyncTask")
@DaggerGenerated
@Generated(
    value = "dagger.internal.codegen.ComponentProcessor",
    comments = "https://dagger.dev"
)
@SuppressWarnings({
    "unchecked",
    "rawtypes",
    "KotlinInternal",
    "KotlinInternalInJava"
})
public final class BaseLayerModule_ProvideCompatAsyncTaskMonitorFactory implements Factory<IdleNotifier<Runnable>> {
  private final BaseLayerModule module;

  private final Provider<ThreadPoolExecutorExtractor> extractorProvider;

  public BaseLayerModule_ProvideCompatAsyncTaskMonitorFactory(BaseLayerModule module,
      Provider<ThreadPoolExecutorExtractor> extractorProvider) {
    this.module = module;
    this.extractorProvider = extractorProvider;
  }

  @Override
  public IdleNotifier<Runnable> get() {
    return provideCompatAsyncTaskMonitor(module, extractorProvider.get());
  }

  public static BaseLayerModule_ProvideCompatAsyncTaskMonitorFactory create(BaseLayerModule module,
      Provider<ThreadPoolExecutorExtractor> extractorProvider) {
    return new BaseLayerModule_ProvideCompatAsyncTaskMonitorFactory(module, extractorProvider);
  }

  public static IdleNotifier<Runnable> provideCompatAsyncTaskMonitor(BaseLayerModule instance,
      Object extractor) {
    return Preconditions.checkNotNullFromProvides(instance.provideCompatAsyncTaskMonitor((ThreadPoolExecutorExtractor) extractor));
  }
}

/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: bazel-out/k8-opt-exec-2B5CBBC6/bin/external/androidsdk/aidl_binary.runfiles/androidsdk/build-tools/35.0.0/aidl -b -Iespresso/web/java/androidx/test/espresso/web/action/idls -Irunner/android_junit_runner/java -Iservices/events/java -Iespresso/web/java/androidx/test/espresso/web/model/idls -pexternal/androidsdk/platforms/android-35/framework.aidl espresso/web/java/androidx/test/espresso/web/action/idls/androidx/test/espresso/web/action/IAtomActionResultPropagator.aidl bazel-out/k8-fastbuild/bin/espresso/web/java/androidx/test/espresso/web/action/action_aidl/espresso/web/java/androidx/test/espresso/web/action/idls/androidx/test/espresso/web/action/IAtomActionResultPropagator.java
 */
package androidx.test.espresso.web.action;
/**
 * Enables the ability to propagate results back from a remote ViewAction running in a different
 * process.
 */
public interface IAtomActionResultPropagator extends android.os.IInterface
{
  /** Default implementation for IAtomActionResultPropagator. */
  public static class Default implements androidx.test.espresso.web.action.IAtomActionResultPropagator
  {
    @Override public void setResult(androidx.test.espresso.web.model.Evaluation eval) throws android.os.RemoteException
    {
    }
    @Override public void setError(android.os.Bundle errorMsg) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements androidx.test.espresso.web.action.IAtomActionResultPropagator
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an androidx.test.espresso.web.action.IAtomActionResultPropagator interface,
     * generating a proxy if needed.
     */
    public static androidx.test.espresso.web.action.IAtomActionResultPropagator asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof androidx.test.espresso.web.action.IAtomActionResultPropagator))) {
        return ((androidx.test.espresso.web.action.IAtomActionResultPropagator)iin);
      }
      return new androidx.test.espresso.web.action.IAtomActionResultPropagator.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_setResult:
        {
          androidx.test.espresso.web.model.Evaluation _arg0;
          _arg0 = _Parcel.readTypedObject(data, androidx.test.espresso.web.model.Evaluation.CREATOR);
          this.setResult(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_setError:
        {
          android.os.Bundle _arg0;
          _arg0 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          this.setError(_arg0);
          reply.writeNoException();
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements androidx.test.espresso.web.action.IAtomActionResultPropagator
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void setResult(androidx.test.espresso.web.model.Evaluation eval) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, eval, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setResult, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public void setError(android.os.Bundle errorMsg) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _Parcel.writeTypedObject(_data, errorMsg, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_setError, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_setResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_setError = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "androidx.test.espresso.web.action.IAtomActionResultPropagator";
  public void setResult(androidx.test.espresso.web.model.Evaluation eval) throws android.os.RemoteException;
  public void setError(android.os.Bundle errorMsg) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
